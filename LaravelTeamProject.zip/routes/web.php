<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\HomeController;
use App\Http\Controllers\AuthController;
use App\Http\Controllers\ArticleController;

use App\Http\Controllers\PortofolioController;


Route::get("/", [HomeController::class,"home"])->name("home.tampil");


Route::get("/registrasi", [AuthController::class,"tampilRegistrasi"])->name("registrasi.tampil");
Route::post("/registrasi/submit", [AuthController::class,"submitRegistrasi"])->name("registrasi.submit");

Route::get("/login", [AuthController::class,"tampilLogin"])->name("login");
Route::post("/login/submit", [AuthController::class,"submitLogin"])->name("login.submit");

Route::get("logout", [AuthController::class,"logout"])->name("logout");

Route::get("/campaign", [ArticleController::class, "articles"]);
Route::get("/article", [ArticleController::class, "article_detail"]);

Route::get('/works', [PortofolioController::class, 'index'])->name('portfolio.index');
Route::get('/works/{id}', [PortofolioController::class, 'show'])->name('portfolio.show');