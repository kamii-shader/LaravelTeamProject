<?php $__env->startSection('content'); ?>
<div class="container">
    <h1><?php echo e($portfolio->title); ?></h1>
    <img src="<?php echo e(asset('storage/images/' . $portfolio->image)); ?>" alt="<?php echo e($portfolio->title); ?>" class="img-fluid mb-4">
    <p><?php echo e($portfolio->description); ?></p>
    <p><strong>Date:</strong> <?php echo e($portfolio->date); ?></p>
    <p><strong>Location:</strong> <?php echo e($portfolio->location); ?></p>
    <a href="<?php echo e(route('portfolio.index')); ?>" class="btn btn-secondary">Back</a>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Folder Kuliahan\Laravel\LaravelTeamProject\resources\views/portofolio-show.blade.php ENDPATH**/ ?>