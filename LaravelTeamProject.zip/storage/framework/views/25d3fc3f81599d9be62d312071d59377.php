

<?php $__env->startSection('title', 'Home'); ?>

<?php $__env->startSection('content'); ?>
    <h1 class="mb-4"><?php echo e($article->title); ?></h1>
    <p class="text-muted">By <?php echo e($article->author); ?> | Published on <?php echo e($article->publish_date); ?></p>

    <?php if($article->images): ?>
        <img src="<?php echo e($article->images); ?>" alt="Image for <?php echo e($article->title); ?>" class="img-fluid rounded mb-3" style="max-height: 400px;">
    <?php endif; ?>

    <div class="content mt-4">
        <p><?php echo nl2br(e($article->content)); ?></p> <!-- Isi artikel dengan format HTML -->
    </div>

    <a href="/campaign" class="btn btn-secondary mt-4">Back to Articles List</a>
    <br><br>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Folder Kuliahan\Laravel\LaravelTeamProject\resources\views/article_detail.blade.php ENDPATH**/ ?>