

<?php $__env->startSection('title', 'Article'); ?>

<?php $__env->startSection('content'); ?>
    <div class="container my-5">
        <h1 class="mb-4 text-center">Article List</h1>
        <div class="list-group">
            
            <?php $__empty_1 = true; $__currentLoopData = $list_article; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <?php
                    $link = "article?id=" . $data->uuid;
                ?>
                <div class="list-group-item list-group-item-action d-flex align-items-start">
                    <img alt="Article Image" src=<?php echo e($data->images); ?> class="me-3 rounded" style="width: 150px; height: auto;">
                    <div>
                        <h5 class="mb-1"><?php echo e($data->title); ?></h5>
                        <p class="text-muted mb-2">By <strong><?php echo e($data->author); ?></strong> | Date: <?php echo e($data->publish_date); ?></p>
                        <p class="mb-2"><?php echo e(Str::limit($data->content, 150)); ?></p>
                        <a href=<?php echo e($link); ?> class="btn btn-primary btn-sm">Read More</a>
                    </div>
                </div>
            
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <h2 class="text-center mb-4">Nothing Article Founded</h2>
            <?php endif; ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Folder Kuliahan\Laravel\LaravelTeamProject\resources\views/articles.blade.php ENDPATH**/ ?>