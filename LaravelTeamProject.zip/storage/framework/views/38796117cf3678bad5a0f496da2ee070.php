<!-- resources/views/layouts/app.blade.php -->
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ECO-Logical</title>
    <link rel="stylesheet" href="<?php echo e(asset('css/app.css')); ?>">
    
</head>
<body>
    <!-- Include Navbar -->
    <?php if(auth()->guard()->guest()): ?>
        <?php echo $__env->make('navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> <!-- Menampilkan navbar jika belum login -->
    <?php else: ?>
        <?php echo $__env->make('navbarafter', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> <!-- Menampilkan navbar setelah login -->
        <div class="text-center">
            <b>Hallo <?php echo e(Auth::user()->name); ?>, Anda berhasil login!</b>
        </div>
    <?php endif; ?>
    
    <!-- Content Section -->
    <div class="container mt-4">
        <?php echo $__env->yieldContent('content'); ?>        
    </div>
</body>
</html>
<?php /**PATH C:\Folder Kuliahan\Laravel\LaravelTeamProject\resources\views/navbar/app.blade.php ENDPATH**/ ?>