<?php $__env->startSection('title', 'Portfolio List'); ?>

<?php $__env->startSection('content'); ?>
    <div class="text-center mb-4">
        <h1>Portfolio</h1>
    </div>

    <!-- Center the portfolio container -->
    <div class="d-flex justify-content-center">
        <div class="row" style="max-width: 1400px;"> <!-- Increased max-width to make cards larger -->
            <div class="row">
             <?php $__currentLoopData = $portfolios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $portfolio): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="card" style="width: 18rem;">
                        <img class="card-img-top" src="<?php echo e(asset('storage/images/' . $portfolio->image)); ?>" alt="Card image cap">
                        <div class="card-body">
                                <h5 class="card-title"><?php echo e($portfolio->date); ?> in <?php echo e($portfolio->location); ?></h5>
                                 <p class="card-text"><?php echo e(\Illuminate\Support\Str::limit($portfolio->description, 150)); ?></p>
                            <a href="<?php echo e(route('portfolio.show', $portfolio->id)); ?>" class="btn btn-primary">View Details</a>
                        </div>
                    </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>
    <style>
    .card-img-top{
        height: 200px;
        width: 100%;
    }

    .card{
        margin-top: 10px;
    }
    </style>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Folder Kuliahan\Laravel\LaravelTeamProject\resources\views/portofolio.blade.php ENDPATH**/ ?>